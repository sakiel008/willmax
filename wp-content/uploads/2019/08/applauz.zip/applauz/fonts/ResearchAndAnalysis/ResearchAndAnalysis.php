<?php

$set = strtolower( basename(__FILE__, '.php') );

$$set = array(
	'analytics-29 (researchandanalysis set)' => $set . '_e900',
	'analytics-28 (researchandanalysis set)' => $set . '_e901',
	'analytics-27 (researchandanalysis set)' => $set . '_e902',
	'analytics-26 (researchandanalysis set)' => $set . '_e903',
	'analytics-25 (researchandanalysis set)' => $set . '_e904',
	'analytics-24 (researchandanalysis set)' => $set . '_e905',
	'analytics-23 (researchandanalysis set)' => $set . '_e906',
	'analytics-22 (researchandanalysis set)' => $set . '_e907',
	'analytics-21 (researchandanalysis set)' => $set . '_e908',
	'analytics-20 (researchandanalysis set)' => $set . '_e909',
	'analytics-19 (researchandanalysis set)' => $set . '_e90a',
	'analytics-18 (researchandanalysis set)' => $set . '_e90b',
	'analytics-17 (researchandanalysis set)' => $set . '_e90c',
	'analytics-16 (researchandanalysis set)' => $set . '_e90d',
	'analytics-15 (researchandanalysis set)' => $set . '_e90e',
	'analytics-14 (researchandanalysis set)' => $set . '_e90f',
	'analytics-13 (researchandanalysis set)' => $set . '_e910',
	'analytics-12 (researchandanalysis set)' => $set . '_e911',
	'analytics-11 (researchandanalysis set)' => $set . '_e912',
	'analytics-10 (researchandanalysis set)' => $set . '_e913',
	'analytics-9 (researchandanalysis set)' => $set . '_e914',
	'analytics-8 (researchandanalysis set)' => $set . '_e915',
	'analytics-7 (researchandanalysis set)' => $set . '_e916',
	'analytics-6 (researchandanalysis set)' => $set . '_e917',
	'analytics-5 (researchandanalysis set)' => $set . '_e918',
	'analytics-4 (researchandanalysis set)' => $set . '_e919',
	'analytics-3 (researchandanalysis set)' => $set . '_e91a',
	'analytics-2 (researchandanalysis set)' => $set . '_e91b',
	'analytics-1 (researchandanalysis set)' => $set . '_e91c',
	'analytics (researchandanalysis set)' => $set . '_e91d'
);