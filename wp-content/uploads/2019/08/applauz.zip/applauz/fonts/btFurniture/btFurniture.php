<?php

$set = strtolower( basename(__FILE__, '.php') );

$$set = array(
	'armchair (btFurniture set)' => $set . '_e900',
	'bed (btFurniture set)' => $set . '_e901',
	'book-shelf-small (btFurniture set)' => $set . '_e902',
	'book-shelf-with-drawers (btFurniture set)' => $set . '_e903',
	'book-shelf (btFurniture set)' => $set . '_e904',
	'breakfast-trolley (btFurniture set)' => $set . '_e905',
	'cabinet-with-drawers-2 (btFurniture set)' => $set . '_e906',
	'cabinet-with-drawers-3 (btFurniture set)' => $set . '_e907',
	'cabinet-with-drawers (btFurniture set)' => $set . '_e908',
	'cabinet (btFurniture set)' => $set . '_e909',
	'chair (btFurniture set)' => $set . '_e90a',
	'chandelier (btFurniture set)' => $set . '_e90b',
	'cottage (btFurniture set)' => $set . '_e90c',
	'desk-lamp (btFurniture set)' => $set . '_e90d',
	'desk (btFurniture set)' => $set . '_e90e',
	'drawer-cabinet-and-alarm-clock (btFurniture set)' => $set . '_e90f',
	'drawer-cabinet (btFurniture set)' => $set . '_e910',
	'entryway-storage (btFurniture set)' => $set . '_e911',
	'fireplace (btFurniture set)' => $set . '_e912',
	'floor-lamp (btFurniture set)' => $set . '_e913',
	'kitchen (btFurniture set)' => $set . '_e914',
	'ladder (btFurniture set)' => $set . '_e915',
	'make-up-desk-with-mirror (btFurniture set)' => $set . '_e916',
	'pc-chair (btFurniture set)' => $set . '_e917',
	'plant (btFurniture set)' => $set . '_e918',
	'retro-chair-2 (btFurniture set)' => $set . '_e919',
	'retro-chair (btFurniture set)' => $set . '_e91a',
	'rocking-chair (btFurniture set)' => $set . '_e91b',
	'round-table (btFurniture set)' => $set . '_e91c',
	'sink (btFurniture set)' => $set . '_e91d',
	'sofa (btFurniture set)' => $set . '_e91e',
	'tv-shelf (btFurniture set)' => $set . '_e91f'
);