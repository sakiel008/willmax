<aside class="btSidebar">
<?php
	dynamic_sidebar( 'primary_widget_area' );
?>
</aside>